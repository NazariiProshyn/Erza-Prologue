#pragma once
#include "Lvl.h"
class Menu: public Lvl
{
public:
	Menu();
};

