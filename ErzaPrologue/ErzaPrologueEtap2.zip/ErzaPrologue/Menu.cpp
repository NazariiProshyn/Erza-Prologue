#include "Menu.h"
namespace NSPaths
{
    const std::string background = "src/images/side/menuBack.png";
    //images/coin10.jpg
};

Menu::Menu()
{
    texture.setTexture(NSPaths::background);
}
