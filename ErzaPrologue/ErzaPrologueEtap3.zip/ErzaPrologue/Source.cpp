
#include "Game.h"
int main()
{
    Game Erza;
    Erza.Run();

    return 0;
}